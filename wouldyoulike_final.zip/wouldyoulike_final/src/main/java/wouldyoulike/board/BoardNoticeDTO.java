package wouldyoulike.board;

public class BoardNoticeDTO extends BoardDTO {

}
